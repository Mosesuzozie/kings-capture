package dev.kingcapture;

import dev.kingcapture.config.KcConfig;
import dev.kingcapture.core.RecordingController;
import dev.kingcapture.ui.HudOverlay;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.util.Identifier;
import org.lwjgl.glfw.GLFW;

public class KingCaptureMod implements ClientModInitializer {
    public static KeyBinding toggleKey;

    @Override
    public void onInitializeClient() {
        KcConfig.load();
        // Unbound by default: GLFW_KEY_UNKNOWN. The player assigns a key under Options > Controls.
        toggleKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.kingcapture.toggle", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_UNKNOWN,
                KeyBinding.Category.create(Identifier.of("kingcapture", "main"))));
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (toggleKey.wasPressed()) {                 // wasPressed counts presses, so holding the key cannot re-trigger
                while (toggleKey.wasPressed()) { }        // swallow queued presses: one toggle per tick at most
                RecordingController.toggle();
            }
        });
        HudOverlay.register();
        ClientLifecycleEvents.CLIENT_STOPPING.register(client -> RecordingController.shutdownBlocking());
        System.out.println("[KingCapture] loaded (FFmpeg natives load lazily on first recording)");
    }
}
