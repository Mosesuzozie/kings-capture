package dev.kingcapture.mixin;

import dev.kingcapture.config.KcConfig;
import dev.kingcapture.core.RecordingController;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.GameMenuScreen;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(GameMenuScreen.class)
public abstract class GameMenuScreenMixin extends Screen {
    protected GameMenuScreenMixin(Text title) { super(title); }

    /** Label follows the controller state every frame, so keybind toggles show up instantly too. */
    private static final class KcButton extends ButtonWidget {
        KcButton(int x, int y, int w, int h) {
            super(x, y, w, h, RecordingController.buttonLabel(), b -> RecordingController.toggle(), DEFAULT_NARRATION_SUPPLIER);
        }
        @Override
        protected void renderWidget(DrawContext ctx, int mx, int my, float delta) {
            setMessage(RecordingController.buttonLabel());
            RecordingController.State s = RecordingController.state();
            this.active = s == RecordingController.State.IDLE || s == RecordingController.State.RECORDING;
            super.renderWidget(ctx, mx, my, delta);
        }
    }

    /**
     * Placed in the top-left corner, outside vanilla's centered button grid, so it never overlaps or moves
     * vanilla / other mods' buttons.
     */
    @Inject(method = "init", at = @At("TAIL"))
    private void kingcapture$addButton(CallbackInfo ci) {
        if (!KcConfig.get().showEscButton) return;
        this.addDrawableChild(new KcButton(6, 6, 150, 20));
    }
}
